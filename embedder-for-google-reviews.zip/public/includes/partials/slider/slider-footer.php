<?php

if (! defined('ABSPATH'))
	exit;
?>

</div><!--swiper-wrapper-->
<!-- If we need pagination -->
<div class="swiper-pagination"></div>

<!-- If we need navigation buttons -->
<div class="slider-prev-next-wrapper">
    <div class="grwp-swiper-button-next"></div>
    <div class="grwp-swiper-button-prev"></div>
</div>

</div> <!--swiper-->



