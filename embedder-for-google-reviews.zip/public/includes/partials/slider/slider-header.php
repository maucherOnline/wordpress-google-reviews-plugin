<?php

if (! defined('ABSPATH'))
	exit;
?>

<!-- Slider main container -->
<div class="swiper reviews_embedder_slider">
	<!-- Additional required wrapper -->
	<div class="swiper-wrapper">
